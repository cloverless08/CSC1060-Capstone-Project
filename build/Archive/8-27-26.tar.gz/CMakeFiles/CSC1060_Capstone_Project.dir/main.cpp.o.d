CMakeFiles/CSC1060_Capstone_Project.dir/main.cpp.o: \
 /home/cdemin/Code/Active/CSC1060\ Capstone\ Project/main.cpp \
 /usr/include/stdc-predef.h /usr/include/SDL2/SDL.h \
 /usr/include/SDL2/SDL_main.h /usr/include/SDL2/SDL_stdinc.h \
 /usr/include/SDL2/SDL_config.h /usr/include/SDL2/SDL_platform.h \
 /usr/include/SDL2/begin_code.h /usr/include/SDL2/close_code.h \
 /usr/include/SDL2/SDL_config_unix.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/limits.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/syslimits.h \
 /usr/include/limits.h /usr/include/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/wordsize.h /usr/include/bits/timesize.h \
 /usr/include/sys/cdefs.h /usr/include/bits/long-double.h \
 /usr/include/gnu/stubs.h /usr/include/gnu/stubs-64.h \
 /usr/include/bits/posix1_lim.h /usr/include/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/bits/posix2_lim.h /usr/include/bits/xopen_lim.h \
 /usr/include/bits/uio_lim.h /usr/include/sys/types.h \
 /usr/include/bits/types.h /usr/include/bits/typesizes.h \
 /usr/include/bits/time64.h /usr/include/bits/types/clock_t.h \
 /usr/include/bits/types/clockid_t.h /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/timer_t.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/stddef.h \
 /usr/include/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/bits/endian.h /usr/include/bits/endianness.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/stdio.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/stdarg.h \
 /usr/include/bits/types/__fpos_t.h /usr/include/bits/types/__mbstate_t.h \
 /usr/include/bits/types/__fpos64_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/floatn.h \
 /usr/include/bits/floatn-common.h /usr/include/c++/15.2.1/stdlib.h \
 /usr/include/c++/15.2.1/cstdlib \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/c++config.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/os_defines.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/cpu_defines.h \
 /usr/include/c++/15.2.1/pstl/pstl_config.h /usr/include/stdlib.h \
 /usr/include/bits/waitflags.h /usr/include/bits/waitstatus.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/alloca.h /usr/include/bits/stdlib-float.h \
 /usr/include/c++/15.2.1/bits/std_abs.h /usr/include/string.h \
 /usr/include/strings.h /usr/include/wchar.h /usr/include/bits/wchar.h \
 /usr/include/bits/types/wint_t.h /usr/include/bits/types/mbstate_t.h \
 /usr/include/inttypes.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/stdint-uintn.h \
 /usr/include/bits/stdint-least.h /usr/include/ctype.h \
 /usr/include/c++/15.2.1/math.h /usr/include/c++/15.2.1/cmath \
 /usr/include/c++/15.2.1/bits/requires_hosted.h \
 /usr/include/c++/15.2.1/bits/cpp_type_traits.h \
 /usr/include/c++/15.2.1/bits/version.h \
 /usr/include/c++/15.2.1/type_traits \
 /usr/include/c++/15.2.1/ext/type_traits.h /usr/include/math.h \
 /usr/include/bits/math-vector.h /usr/include/bits/libm-simd-decl-stubs.h \
 /usr/include/bits/flt-eval-method.h /usr/include/bits/fp-logb.h \
 /usr/include/bits/fp-fast.h /usr/include/bits/mathcalls-macros.h \
 /usr/include/bits/mathcalls-helper-functions.h \
 /usr/include/bits/mathcalls.h /usr/include/bits/mathcalls-narrow.h \
 /usr/include/bits/iscanonical.h /usr/include/c++/15.2.1/bits/specfun.h \
 /usr/include/c++/15.2.1/bits/stl_algobase.h \
 /usr/include/c++/15.2.1/bits/functexcept.h \
 /usr/include/c++/15.2.1/bits/exception_defines.h \
 /usr/include/c++/15.2.1/ext/numeric_traits.h \
 /usr/include/c++/15.2.1/bits/stl_pair.h \
 /usr/include/c++/15.2.1/bits/move.h \
 /usr/include/c++/15.2.1/bits/utility.h \
 /usr/include/c++/15.2.1/bits/stl_iterator_base_types.h \
 /usr/include/c++/15.2.1/bits/stl_iterator_base_funcs.h \
 /usr/include/c++/15.2.1/bits/concept_check.h \
 /usr/include/c++/15.2.1/debug/assertions.h \
 /usr/include/c++/15.2.1/bits/stl_iterator.h \
 /usr/include/c++/15.2.1/bits/ptr_traits.h \
 /usr/include/c++/15.2.1/debug/debug.h \
 /usr/include/c++/15.2.1/bits/predefined_ops.h \
 /usr/include/c++/15.2.1/bit /usr/include/c++/15.2.1/concepts \
 /usr/include/c++/15.2.1/limits /usr/include/c++/15.2.1/tr1/gamma.tcc \
 /usr/include/c++/15.2.1/tr1/special_function_util.h \
 /usr/include/c++/15.2.1/tr1/bessel_function.tcc \
 /usr/include/c++/15.2.1/tr1/beta_function.tcc \
 /usr/include/c++/15.2.1/tr1/ell_integral.tcc \
 /usr/include/c++/15.2.1/tr1/exp_integral.tcc \
 /usr/include/c++/15.2.1/tr1/hypergeometric.tcc \
 /usr/include/c++/15.2.1/tr1/legendre_function.tcc \
 /usr/include/c++/15.2.1/tr1/modified_bessel_func.tcc \
 /usr/include/c++/15.2.1/tr1/poly_hermite.tcc \
 /usr/include/c++/15.2.1/tr1/poly_laguerre.tcc \
 /usr/include/c++/15.2.1/tr1/riemann_zeta.tcc \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/float.h \
 /usr/include/SDL2/SDL_assert.h /usr/include/SDL2/SDL_atomic.h \
 /usr/include/SDL2/SDL_audio.h /usr/include/SDL2/SDL_error.h \
 /usr/include/SDL2/SDL_endian.h /usr/include/SDL2/SDL_mutex.h \
 /usr/include/SDL2/SDL_thread.h /usr/include/SDL2/SDL_rwops.h \
 /usr/include/SDL2/SDL_clipboard.h /usr/include/SDL2/SDL_cpuinfo.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/immintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/x86gprintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/ia32intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/adxintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/bmiintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/bmi2intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/cetintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/cldemoteintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/clflushoptintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/clwbintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/clzerointrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/cmpccxaddintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/enqcmdintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/fxsrintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/lzcntintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/lwpintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/movdirintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/mwaitintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/mwaitxintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/pconfigintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/popcntintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/pkuintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/prfchiintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/raointintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/rdseedintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/rtmintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/serializeintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/sgxintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/tbmintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/tsxldtrkintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/uintrintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/waitpkgintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/wbnoinvdintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/xsaveintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/xsavecintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/xsaveoptintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/xsavesintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/xtestintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/hresetintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/usermsrintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/mmintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/xmmintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/mm_malloc.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/emmintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/pmmintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/tmmintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/smmintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/wmmintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avxintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avxvnniintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avxifmaintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avxvnniint8intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avxvnniint16intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx2intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512fintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512cdintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512bwintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512dqintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vlbwintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vldqintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512ifmaintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512ifmavlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vbmiintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vbmivlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vpopcntdqintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vbmi2intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vbmi2vlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vnniintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vnnivlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vpopcntdqvlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512bitalgintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512bitalgvlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vp2intersectintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512vp2intersectvlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512fp16intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512fp16vlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/shaintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/sm3intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/sha512intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/sm4intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/fmaintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/f16cintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/gfniintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/vaesintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/vpclmulqdqintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512bf16vlintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx512bf16intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avxneconvertintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxtileintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxint8intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxbf16intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxcomplexintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxavx512intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxtf32intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxtransposeintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxfp8intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/prfchwintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/keylockerintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxfp16intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2mediaintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2-512mediaintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2convertintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2-512convertintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2bf16intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2-512bf16intrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2satcvtintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2-512satcvtintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2minmaxintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2-512minmaxintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/avx10_2copyintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/movrsintrin.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/amxmovrsintrin.h \
 /usr/include/SDL2/SDL_events.h /usr/include/SDL2/SDL_video.h \
 /usr/include/SDL2/SDL_pixels.h /usr/include/SDL2/SDL_rect.h \
 /usr/include/SDL2/SDL_surface.h /usr/include/SDL2/SDL_blendmode.h \
 /usr/include/SDL2/SDL_keyboard.h /usr/include/SDL2/SDL_keycode.h \
 /usr/include/SDL2/SDL_scancode.h /usr/include/SDL2/SDL_mouse.h \
 /usr/include/SDL2/SDL_joystick.h /usr/include/SDL2/SDL_guid.h \
 /usr/include/SDL2/SDL_gamecontroller.h /usr/include/SDL2/SDL_sensor.h \
 /usr/include/SDL2/SDL_quit.h /usr/include/SDL2/SDL_gesture.h \
 /usr/include/SDL2/SDL_touch.h /usr/include/SDL2/SDL_filesystem.h \
 /usr/include/SDL2/SDL_haptic.h /usr/include/SDL2/SDL_hidapi.h \
 /usr/include/SDL2/SDL_hints.h /usr/include/SDL2/SDL_loadso.h \
 /usr/include/SDL2/SDL_log.h /usr/include/SDL2/SDL_messagebox.h \
 /usr/include/SDL2/SDL_metal.h /usr/include/SDL2/SDL_power.h \
 /usr/include/SDL2/SDL_render.h /usr/include/SDL2/SDL_shape.h \
 /usr/include/SDL2/SDL_system.h /usr/include/SDL2/SDL_timer.h \
 /usr/include/SDL2/SDL_version.h /usr/include/SDL2/SDL_locale.h \
 /usr/include/SDL2/SDL_misc.h /usr/include/c++/15.2.1/vector \
 /usr/include/c++/15.2.1/bits/allocator.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/c++allocator.h \
 /usr/include/c++/15.2.1/bits/new_allocator.h /usr/include/c++/15.2.1/new \
 /usr/include/c++/15.2.1/bits/exception.h \
 /usr/include/c++/15.2.1/bits/memoryfwd.h \
 /usr/include/c++/15.2.1/bits/stl_construct.h \
 /usr/include/c++/15.2.1/bits/stl_uninitialized.h \
 /usr/include/c++/15.2.1/ext/alloc_traits.h \
 /usr/include/c++/15.2.1/bits/alloc_traits.h \
 /usr/include/c++/15.2.1/bits/stl_vector.h \
 /usr/include/c++/15.2.1/initializer_list \
 /usr/include/c++/15.2.1/bits/stl_bvector.h \
 /usr/include/c++/15.2.1/bits/functional_hash.h \
 /usr/include/c++/15.2.1/bits/hash_bytes.h \
 /usr/include/c++/15.2.1/bits/refwrap.h \
 /usr/include/c++/15.2.1/bits/invoke.h \
 /usr/include/c++/15.2.1/bits/stl_function.h \
 /usr/include/c++/15.2.1/backward/binders.h \
 /usr/include/c++/15.2.1/bits/range_access.h \
 /usr/include/c++/15.2.1/bits/vector.tcc \
 /usr/include/c++/15.2.1/bits/memory_resource.h \
 /usr/include/c++/15.2.1/cstddef \
 /usr/include/c++/15.2.1/bits/uses_allocator.h \
 /usr/include/c++/15.2.1/bits/uses_allocator_args.h \
 /usr/include/c++/15.2.1/tuple /usr/include/c++/15.2.1/iostream \
 /usr/include/c++/15.2.1/ostream /usr/include/c++/15.2.1/bits/ostream.h \
 /usr/include/c++/15.2.1/ios /usr/include/c++/15.2.1/iosfwd \
 /usr/include/c++/15.2.1/bits/stringfwd.h \
 /usr/include/c++/15.2.1/bits/postypes.h /usr/include/c++/15.2.1/cwchar \
 /usr/include/c++/15.2.1/exception \
 /usr/include/c++/15.2.1/bits/exception_ptr.h \
 /usr/include/c++/15.2.1/bits/cxxabi_init_exception.h \
 /usr/include/c++/15.2.1/typeinfo \
 /usr/include/c++/15.2.1/bits/nested_exception.h \
 /usr/include/c++/15.2.1/bits/char_traits.h \
 /usr/include/c++/15.2.1/bits/localefwd.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/c++locale.h \
 /usr/include/c++/15.2.1/clocale /usr/include/locale.h \
 /usr/include/bits/locale.h /usr/include/c++/15.2.1/cctype \
 /usr/include/c++/15.2.1/bits/ios_base.h \
 /usr/include/c++/15.2.1/ext/atomicity.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/gthr.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/gthr-default.h \
 /usr/include/pthread.h /usr/include/sched.h /usr/include/bits/sched.h \
 /usr/include/linux/sched/types.h /usr/include/linux/types.h \
 /usr/include/asm/types.h /usr/include/asm-generic/types.h \
 /usr/include/asm-generic/int-ll64.h /usr/include/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h /usr/include/asm/posix_types.h \
 /usr/include/asm/posix_types_64.h /usr/include/asm-generic/posix_types.h \
 /usr/include/bits/types/struct_sched_param.h /usr/include/bits/cpu-set.h \
 /usr/include/time.h /usr/include/bits/time.h /usr/include/bits/timex.h \
 /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/struct_itimerspec.h /usr/include/bits/setjmp.h \
 /usr/include/bits/types/struct___jmp_buf_tag.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/atomic_word.h \
 /usr/include/sys/single_threaded.h \
 /usr/include/c++/15.2.1/bits/locale_classes.h \
 /usr/include/c++/15.2.1/string \
 /usr/include/c++/15.2.1/bits/ostream_insert.h \
 /usr/include/c++/15.2.1/bits/cxxabi_forced.h \
 /usr/include/c++/15.2.1/bits/basic_string.h \
 /usr/include/c++/15.2.1/string_view \
 /usr/include/c++/15.2.1/bits/string_view.tcc \
 /usr/include/c++/15.2.1/ext/string_conversions.h \
 /usr/include/c++/15.2.1/cstdio /usr/include/c++/15.2.1/cerrno \
 /usr/include/errno.h /usr/include/bits/errno.h \
 /usr/include/linux/errno.h /usr/include/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/bits/types/error_t.h \
 /usr/include/c++/15.2.1/bits/charconv.h \
 /usr/include/c++/15.2.1/bits/basic_string.tcc \
 /usr/include/c++/15.2.1/bits/locale_classes.tcc \
 /usr/include/c++/15.2.1/system_error \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/error_constants.h \
 /usr/include/c++/15.2.1/stdexcept /usr/include/c++/15.2.1/streambuf \
 /usr/include/c++/15.2.1/bits/streambuf.tcc \
 /usr/include/c++/15.2.1/bits/basic_ios.h \
 /usr/include/c++/15.2.1/bits/locale_facets.h \
 /usr/include/c++/15.2.1/cwctype /usr/include/wctype.h \
 /usr/include/bits/wctype-wchar.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/ctype_base.h \
 /usr/include/c++/15.2.1/bits/streambuf_iterator.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/ctype_inline.h \
 /usr/include/c++/15.2.1/bits/locale_facets.tcc \
 /usr/include/c++/15.2.1/bits/basic_ios.tcc \
 /usr/include/c++/15.2.1/bits/ostream.tcc /usr/include/c++/15.2.1/istream \
 /usr/include/c++/15.2.1/bits/istream.tcc /usr/include/c++/15.2.1/array \
 /usr/include/c++/15.2.1/compare /usr/include/c++/15.2.1/random \
 /usr/include/c++/15.2.1/cstdint /usr/include/c++/15.2.1/bits/random.h \
 /usr/include/c++/15.2.1/bits/uniform_int_dist.h \
 /usr/include/c++/15.2.1/x86_64-pc-linux-gnu/bits/opt_random.h \
 /usr/include/c++/15.2.1/bits/random.tcc /usr/include/c++/15.2.1/numeric \
 /usr/include/c++/15.2.1/bits/stl_numeric.h \
 /usr/include/c++/15.2.1/pstl/glue_numeric_defs.h \
 /usr/include/c++/15.2.1/pstl/execution_defs.h \
 /home/cdemin/Code/Active/CSC1060\ Capstone\ Project/main_utils.h
